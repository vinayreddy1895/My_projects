Back end part of the user story management tool.

In_sync with front end consists all the files which are resonance with the front end and the other folder not_in_sync_with_frontend is currently not in resonance with the frontend.
