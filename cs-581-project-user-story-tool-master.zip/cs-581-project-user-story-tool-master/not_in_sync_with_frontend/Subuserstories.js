const Sequelize = require("sequelize");
const db = require("../db/connection");
module.exports = db.sequelize.define(
  "Subuserstories",
  {
    userstory_id: {
      type: Sequelize.STRING
    },
    sub_userstory_id: {
      type: Sequelize.STRING
    },
    sub_userstory_desc: {
      type: Sequelize.STRING
    },
    sub_userstory_analysis: {
      type: Sequelize.INT
    },
    sub_userstory_coding: {
      type: Sequelize.INT
    },
    sub_userstory_testing: {
      type: Sequelize.INT
    }
  },
  {
    timestamps: false
  }
);
