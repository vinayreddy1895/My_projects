const express = require("express");
const users = express.Router();
const subuserstories_model = require("../models/Subuserstories");

users.post("/registersubuserstories", (req, res) => {
  //const today = new Date().toDateString();
  const userData = {
    id: req.body.id,
    userstory_id: req.body.userstory_id,
    sub_userstory_id: req.body.sub_userstory_id,
    sub_userstory_desc: req.body.sub_userstory_desc,
    sub_userstory_analysis: req.body.sub_userstory_analysis,
    sub_userstory_coding: req.body.sub_userstory_coding,
    sub_userstory_testing: req.body.sub_userstory_testing
  };
  subuserstories_model
    .findAll({
      where: {
        userstory_id: req.body.userstory_id
      }
    })
    .then(subuserstorie => {
      //console.log("iam h");
      console.log(subuserstorie.length);
      if (subuserstorie.length > 0) {
        console.log("iam h");
        subuserstories_model
          .create(userData)
          .then(subuserstorie => {
            res.json(" sub user story added");
          })
          .catch(err => {
            res.send("error: " + err);
          });
      } else {
        res.json({ error: "No combination for user story and sub user story" });
      }
    })
    .catch(err => {
      res.send("error: " + err);
    });
});

module.exports = users;
