const Sequelize = require("sequelize");
const db = require("../db/connection");
module.exports = db.sequelize.define(
  "Userstories",
  {
    userstory_id: {
      type: Sequelize.STRING
    },
    userstory_done_by: {
      type: Sequelize.STRING
    },
    userstory_to_test_by: {
      type: Sequelize.INT
    },
    testing_status: {
      type: Sequelize.INT
    }
  },
  {
    timestamps: false
  }
);
