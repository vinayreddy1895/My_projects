const express = require("express");
const users111 = express.Router();
//const user_model = require("../models/Users");
//let userstoryvar = [];
const subuserstories_model = require("../models/Subuserstories");

users111.put("/subuserstoriesupdate", (req, res) => {
  let updateValues = {
    id: req.body.id,
    userstory_id: req.body.userstory_id,
    sub_userstory_id: req.body.sub_userstory_id,
    sub_userstory_desc: req.body.sub_userstory_desc,
    //userstory_status: req.body.userstory_status,
    sub_userstory_analysis: req.body.sub_userstory_analysis,
    //user_id: req.body.user_id,
    sub_userstory_coding: req.body.sub_userstory_coding,
    sub_userstory_testing: req.body.sub_userstory_testing
  };
  subuserstories_model
    .update(updateValues, {
      where: {
        userstory_id: req.body.userstory_id,
        sub_userstory_id: req.body.sub_userstory_id
      }
    })
    .then(result => {
      if (result == 1) {
        //console.log(result);
        res.json("update successfull");
      } else {
        // After the changes are made compare the changes with the first brought details of user story and then allow it in then we can avoid both cases in the else brach
        res.json(
          "either user/user story combo not found or no changes were made in the database"
        );
      }
    });
});

// users111.post("/userstoriesupdate", (req, res) => {
//   userstories_model
//     .findAll({
//       where: {
//         user_id: req.body.user_id,
//         userstory_id: req.body.userstory_id
//       }
//     })
//     .then(userstorie => {
//       if (userstorie.length > 0) {
//         console.log("i am here");
//         (userstory_description = req.body.userstory_description),
//           (userstory_status = req.body.userstory_status),
//           (userstory_analysis = req.body.userstory_analysis),
//           (userstory_coding = req.body.userstory_coding),
//           (userstory_testing = req.body.userstory_testing);
//         res.status(200).json({ success: "userstory is updated" });
//       } else {
//         res.status(400).json({ error: "User stories not found for update" });
//       }
//     })
//     .catch(err => {
//       res.status(400).json({ error: err });
//     });
// });
module.exports = users111;
