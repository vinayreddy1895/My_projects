const express = require("express");
const users111 = express.Router();
//const user_model = require("../models/Users");
let userstoryvar = [];
const subuserstories_model = require("../models/Subuserstories");
users111.post("/fetchsubuserstories", (req, res) => {
  subuserstories_model
    .findAll({
      where: {
        userstory_id: req.body.userstory_id
        //userstory_status: req.body.userstory_status
      }
    })
    .then(subuserstorie => {
      if (subuserstorie.length > 0) {
        //console.log(userstorie.length);
        //for (i = 0; i < userstorie.length; i++) {

        //userstoryvar += <br></br>;
        //console.log(userstorie[i].dataValues.userstory_description);
        //}
        //console.log(userstorie.length);
        //console.log(userstorie[1].dataValues.userstory_description);
        //if (req.body.password === user.password) {
        res.status(200).json({ subuserstorie });
      } else {
        res
          .status(400)
          .json({ error: "User stories for the selection not available" });
      }
    })
    .catch(err => {
      res.status(400).json({ error: err });
    });
});
module.exports = users111;
