const express = require("express");
const users = express.Router();
const User_Model = require("../models/userstories");

users.post("/registeruserstories", (req, res) => {
  //const today = new Date().toDateString();
  const userData = {
    user_id: req.body.user_id,
    userstory_id: req.body.userstory_id,
    userstory_name: req.body.userstory_name,
    userstory_description_As: req.body.userstory_description_As,
    userstory_description_I: req.body.userstory_description_I,
    userstory_description_So: req.body.userstory_description_So,
    userstory_priority: req.body.userstory_priority,
  };
  User_Model.findOne({
    where: {
      userstory_id: req.body.userstory_id,
    },
  })
    .then((user) => {
      console.log("i am here");
      if (!user) {
        User_Model.create(userData)
          .then((user) => {
            res.json({ status: user.user_id + " registered" });
          })
          .catch((err) => {
            res.send("error: " + err);
          });
      } else {
        res.json({ error: "User already exists" });
      }
    })
    .catch((err) => {
      res.send("error: " + err);
    });
});
users.post("/fetchstories", (req, res) => {
  User_Model.findAll({
    where: {
      user_id: req.body.user_id,
    },
  }).then((users) => {
    res.json({ users });
  });
});

users.put("/edituserstories", (req, res) => {
  let updateValues = {
    user_id: req.body.user_id,
    userstory_name: req.body.userstory_name,
    userstory_description_As: req.body.userstory_description_As,
    userstory_description_I: req.body.userstory_description_I,
    userstory_description_So: req.body.userstory_description_So,
    userstory_priority: req.body.userstory_priority,
  };
  User_Model.update(updateValues, {
    where: { userstory_id: req.body.userstory_id },
  }).then((result) => {
    // here your result is simply an array with number of affected rows
    if (result == 1) {
      console.log(result);
      res.json({ updateValues });
    } else {
      res.json("No update took place");
    }
    // [ 1 ]
  });
});

users.post("/deleteuserstories", (req, res) => {
  User_Model.destroy({ where: { userstory_id: req.body.userstory_id } }).then(
    (result) => {
      if (result == 1) {
        console.log(result);
        res.json("Deleted successfully");
      } else {
        res.json("Enter the correct user_storyid");
      }
      // [ 1 ]
    }
  );
});

module.exports = users;
