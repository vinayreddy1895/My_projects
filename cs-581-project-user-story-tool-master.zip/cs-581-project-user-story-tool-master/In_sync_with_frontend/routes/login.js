const express = require("express");
const users = express.Router();
const User = require("../models/Users");
users.post("/login", (req, res) => {
  User.findOne({
    where: {
      user_id: req.body.user_id
    }
  })
    .then(user => {
      if (user) {
        if (req.body.password === User.password) {
          res.status(200).json({ suceess: "User exists" });
        }
      } else {
        res.status(400).json({ error: "User does not exist" });
      }
    })
    .catch(err => {
      res.status(400).json({ error: err });
    });
});
module.exports = users;
