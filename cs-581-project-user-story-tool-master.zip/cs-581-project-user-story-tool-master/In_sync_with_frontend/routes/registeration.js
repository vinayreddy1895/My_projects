const express = require("express");
const users = express.Router();
const User_Model = require("../models/Users");

users.post("/register", (req, res) => {
  //const today = new Date().toDateString();
  const userData = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    user_role: req.body.user_role,
    email_id: req.body.email_id,
    user_id: req.body.user_id,
    password: req.body.password
  };
  User_Model.findOne({
    where: {
      user_id: req.body.user_id
    }
  })
    .then(user => {
      if (!user) {
        User_Model.create(userData)
          .then(user => {
            res.json({ status: user.user_id + " registered" });
          })
          .catch(err => {
            res.send("error: " + err);
          });
      } else {
        res.json({ error: "User already exists" });
      }
    })
    .catch(err => {
      res.send("error: " + err);
    });
});

module.exports = users;
