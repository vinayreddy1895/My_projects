const Sequelize = require("sequelize");
const db = require("../db/connection");
module.exports = db.sequelize.define(
  "userstories",
  {
    userstory_id: {
      type: Sequelize.STRING
    },
    userstory_description: {
      type: Sequelize.STRING
    },
    userstory_status: {
      type: Sequelize.STRING
    },
    userstory_analysis: {
      type: Sequelize.INTEGER
    },
    user_id: {
      type: Sequelize.STRING
    },
    userstory_coding: {
      type: Sequelize.INTEGER
    },
    userstory_testing: {
      type: Sequelize.INTEGER
    }
  },
  {
    timestamps: false
  }
);
