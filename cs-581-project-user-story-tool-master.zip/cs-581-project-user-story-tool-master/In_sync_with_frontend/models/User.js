const Sequelize = require("sequelize");
const db = require("../db/connection");
module.exports = db.sequelize.define(
  "user",
  {
    first_name: {
      type: Sequelize.STRING
    },
    last_name: {
      type: Sequelize.STRING
    },
    user_role: {
      type: Sequelize.STRING
    },
    email_id: {
      type: Sequelize.STRING
    },
    user_id: {
      type: Sequelize.STRING,
      primaryKey: true
    },
    password: {
      type: Sequelize.STRING
    }
  },
  {
    timestamps: false
  }
);
