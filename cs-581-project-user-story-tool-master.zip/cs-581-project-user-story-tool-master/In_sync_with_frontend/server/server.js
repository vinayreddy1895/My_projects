var express = require("express");
var bodyParser = require("body-parser");
var app = express();
var port = process.env.PORT || 5000;
//var Users = require("./routes/Users.js");
app.use(bodyParser.json());
var signup = require("./routes/registeration");
app.use("/users", signup);
var signin = require("./routes/login");
app.use("/users", signin);
//app.get("/", (req, res) => res.send("Hello World!"));
//app.get("/, (req, res) => res.send("Hello World!"));
app.listen(port, () => {
  console.log("Server is running on port: " + port);
});
